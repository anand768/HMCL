$(document).ready(function(){
    $('input[type="checkbox"]').click(function(){
    	 if ($(this).is(':checked')) {
           $(this).closest('.list_content').addClass('border border-danger bg-light');  
        }
        else{
        	$(this).closest('.list_content').removeClass('border border-danger bg-light');
        }
    });
});